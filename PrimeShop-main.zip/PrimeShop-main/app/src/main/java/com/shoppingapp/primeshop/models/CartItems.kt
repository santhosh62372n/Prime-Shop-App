package com.shoppingapp.primeshop.models

data class CartItems(val key: String, val value: String)



